# RSAEncryptionService
JAVA MUST BE INSTALLED ON YOUR MACHINE PRIOR TO USE!
![image](https://github.com/vpq5kd/RSAEncryptionService/assets/113056624/bfeefe05-ea6b-4315-8435-2ebd39108796)

To Install:
-------
*Note* -> Sometimes windows defender likes to block this application because it contains a .exe file without a certificate/signature. All the .exe file does is open powershell and run java -jar RSAEncryption.jar. If you are having trouble with windows defender blocking or automatically deleting this program, fist create a new folder on your machine and give it special permissions in windows defender. Then, simply drag and drop this program into that folder and it should be fine. <-This may have been patched with the latest .exe file that I wrote, which now can only be run as admin. However, chrome still blocks it, so just override it. 

- Latest Windows/Java release is under releases. Download the zip file, move it to where you want the program to live, and extract its contents.
- If you are on a windows machine, you can move the included SRSA shortcut (with the key icon) to your desktop for ease of use.
- If you are not on a windows machine don't worry! You can still run the included jar file using java -jar RSAEncryption.jar, just make sure you are running it from its original directory.
-------
To Run:
-------
- If you just want to run the jar file, or are not on a windows machine, cd to the extracted directory and type java -jar RSAEncryption.jar
- If you are on a windows machine and want to run it through the .exe file, simply double-click the aforementioned shortcut and it should run automatically.
---------
